# Landing Page 设计需求文档

## 📋 项目概述

**产品名称**: ximu  
**项目类型**: Landing Page 重新设计  
**技术栈**: Next.js 14 + React + TypeScript + Tailwind CSS  
**目标**: 设计一个现代化、专业的 landing page，展示 ximu 品牌在 AI 搜索分析领域的价值主张

---

## 🎨 设计系统

### 品牌色彩

#### 主品牌色（Brand Colors）
```
主色（Brand 600）: #13458c  - 深蓝色（主要按钮、链接、强调色）
Brand 700:        #0f3870  - 悬停状态
Brand 800:        #0b2b54  - 激活状态
Brand 300:        #426aa3  - 中等偏深蓝色
Brand 200:        #718fba  - 中等蓝色
Brand 100:        #a1b5d1  - 中等偏浅蓝色
Brand 50:         #d0dae8  - 最浅蓝色/浅灰蓝色
```

#### 中性色（Ink Colors）
```
Ink 900: #111827  - 主要文本（标题、重要内容）
Ink 700: #374151  - 次要文本
Ink 600: #4B5563  - 辅助文本
Ink 500: #6B7280  - 占位文本
Ink 400: #9CA3AF  - 禁用文本
Ink 300: #D1D5DB  - 边框
Ink 200: #E5E7EB  - 浅边框
Ink 100: #F3F4F6  - 浅背景
Ink 50:  #F9FAFB  - 极浅背景
```

#### 语义色彩
```
Good:  #16A34A  - 成功/正面
Bad:   #DC2626  - 错误/负面
Info:  #3B82F6  - 信息提示
```

### 字体系统

**字体族**: Inter, Noto Sans CJK SC, system-ui, -apple-system, Segoe UI, Roboto, sans-serif

**字号规范**:
```
2xs:  11px / 16px  - 说明文字、标签
xs:   12px / 18px  - 小号文本
sm:   13px / 20px  - 正文小号
base: 14px / 22px  - 正文标准
lg:   16px / 24px  - 标题小号
xl:   20px / 28px  - 标题中号
2xl:  24px / 32px  - 标题大号
```

### 间距系统

**容器间距**:
- 页面水平间距: `40px` (pageX)
- 页面垂直间距: `32px` (pageY)
- 容器最大宽度: `1400px` (2xl)

**组件间距**:
- 使用 Tailwind 标准间距: 4px, 8px, 12px, 16px, 20px, 24px, 32px, 48px, 64px

### 圆角系统

```
sm:    calc(var(--radius) - 4px)  - 小圆角
md:    calc(var(--radius) - 2px)  - 中圆角
DEFAULT: 0.5rem (8px)             - 标准圆角
lg:    12px                       - 大圆角
xl:    16px                       - 超大圆角
2xl:   20px                       - 最大圆角
```

### 阴影系统

```
subtle: 0 1px 2px rgba(17,24,39,0.04)  - 轻微阴影（卡片、按钮）
```

---

## 📐 页面结构

### 1. Header（导航栏）

**位置**: 页面顶部，sticky 定位  
**高度**: 64px (h-16)  
**背景**: 白色，95% 透明度，带 backdrop-blur 效果  
**内容**:
- **左侧**: Logo（ximu logo，高度 36px）
- **中间**: 导航链接（桌面端显示，移动端隐藏）
  - Pricing
  - Docs
  - Blog
- **右侧**: 操作按钮
  - Login（ghost 按钮）
  - Start Free Trial（主按钮）

**样式要求**:
- 导航链接: `text-sm font-medium text-ink-700 hover:text-brand-600`
- 底部边框: `border-b border-ink-200`
- 响应式: 移动端隐藏导航，显示汉堡菜单（可选）

### 2. Hero Section（主标题区）

**位置**: Header 下方，全屏高度  
**布局**: 居中，垂直居中  
**内容**:
- **主标题**: "Gain the Competitive Edge in the AI Era"
  - 字号: `text-4xl sm:text-5xl lg:text-6xl`
  - 字重: `font-bold`
  - 颜色: `text-ink-900`
  - 间距: `mb-6`
- **副标题**: "ximu helps you see and understand your brand's influence in AI search, track visibility and sentiment metrics, and discover high-potential acquisition channels."
  - 字号: `text-lg sm:text-xl`
  - 颜色: `text-ink-600`
  - 最大宽度: `max-w-2xl`
  - 间距: `mb-12`
- **CTA 按钮组**:
  - "Start 7-day free trial"（主按钮，brand-600）
  - "Talk to sales"（outline 按钮）
  - 响应式: 移动端垂直排列，桌面端水平排列

**样式要求**:
- 背景: 白色
- 最小高度: `min-h-[calc(100vh-4rem)]`
- 内边距: `py-24 px-4 sm:px-6 lg:px-8`

### 3. Features Section（功能展示区）

**位置**: Hero Section 下方  
**背景**: `bg-ink-50`  
**布局**: 容器居中，最大宽度 `max-w-7xl`  
**内容**:

#### 3.1 Section Header
- **标题**: "Powerful Features"
  - 字号: `text-3xl`
  - 字重: `font-bold`
  - 颜色: `text-ink-900`
  - 间距: `mb-4`
- **描述**: "Everything you need to track and analyze your brand's performance"
  - 字号: `text-lg`
  - 颜色: `text-ink-600`
  - 最大宽度: `max-w-2xl mx-auto`
  - 间距: `mb-16`

#### 3.2 Feature Cards（3个功能卡片，垂直排列，间距 `space-y-20`）

**Feature 1: Brand Influence**
- **布局**: 桌面端左右分栏（2/5 文字 + 3/5 图片），移动端垂直排列
- **文字区域**:
  - 标题: "Brand Influence" (`text-3xl font-semibold text-ink-900 mb-6`)
  - 描述: "Comprehensively track your brand's influence metrics in AI search, understand your brand's overall performance and market position across multiple AI platforms, and make more informed brand decisions."
  - 字号: `text-lg text-ink-600 leading-relaxed`
- **图片区域**:
  - 宽高比: `aspect-[4/3]`
  - 背景: `bg-ink-50`
  - 边框: `border border-ink-200`
  - 圆角: `rounded-lg`
  - 图片路径: `/features/brand-influence.png`
  - 占位符: 如果图片不存在，显示占位文本

**Feature 2: Brand Visibility**
- **布局**: 桌面端右左分栏（图片在左，文字在右），移动端垂直排列
- **文字区域**: 同 Feature 1 样式
- **图片区域**: 同 Feature 1 样式
- **图片路径**: `/features/brand-visibility.png`

**Feature 3: Sentiment Analysis**
- **布局**: 桌面端左右分栏（2/5 文字 + 3/5 图片），移动端垂直排列
- **文字区域**: 同 Feature 1 样式
- **图片区域**: 同 Feature 1 样式
- **图片路径**: `/features/sentiment-analysis.png`

**卡片样式**:
- 背景: `bg-white`
- 圆角: `rounded-xl`
- 边框: `border border-ink-200`
- 阴影: `shadow-sm`
- 内边距: `p-8 lg:p-12`（文字区域）

### 4. Footer（页脚）

**位置**: 页面底部  
**背景**: `bg-ink-900`（深色背景）  
**文字颜色**: 白色  
**布局**: 3 列网格（桌面端），单列（移动端）  
**内容**:

#### 4.1 上部分（Upper Footer）
- **左列 - 品牌信息**:
  - 标题: "Gain the Competitive Edge" (`text-lg font-bold text-white mb-1`)
  - 副标题: "in the AI Era" (`text-sm text-ink-400 mb-4`)
  - Logo: ximu logo（白色版本，宽度 100px，高度 36px）
  - Logo 路径: `/ximu-logo-horizontal-white.svg`
- **中列 - 产品/公司链接**:
  - 标题: "Product / Company" (`text-sm font-semibold text-white mb-4`)
  - 链接列表:
    - Home (`/`)
    - Docs (`/docs`)
    - Pricing (`/pricing`)
  - 链接样式: `text-sm text-ink-300 hover:text-white`
- **右列 - 社交媒体**:
  - 标题: "Follow Us" (`text-sm font-semibold text-white mb-4`)
  - 链接列表:
    - x.com (Twitter/X) - `https://x.com`
    - LinkedIn - `https://linkedin.com`
  - 图标: SVG 图标，`w-4 h-4`
  - 链接样式: `text-sm text-ink-300 hover:text-white`

#### 4.2 下部分（Lower Footer）
- **分隔线**: `border-t border-ink-700 pt-8`
- **左侧**: 版权信息
  - 文本: "© {当前年份} ximu. All rights reserved."
  - 样式: `text-sm text-ink-400`
- **右侧**: 法律链接
  - Privacy Policy (`/privacy`)
  - Terms of Services (`/terms`)
  - Imprint (`/imprint`)
  - 样式: `text-sm text-ink-400 hover:text-white`
  - 间距: `gap-6`

**内边距**: `py-12 px-4 sm:px-6 lg:px-8`

---

## 🖼️ 资源文件清单

### Logo 文件
- **蓝色 Logo（Header 使用）**: `/public/ximu-logo-horizontal-blue.svg`
  - 尺寸: 宽度 = 高度 × 2.78（宽高比 2.78:1）
  - 在 Header 中显示高度: 36px
- **白色 Logo（Footer 使用）**: `/public/ximu-logo-horizontal-white.svg`
  - 尺寸: 宽度 100px，高度 36px

### 功能截图
- **Brand Influence**: `/public/features/brand-influence.png`
  - 建议尺寸: 1920×1440px 或更高（4:3 比例）
  - 格式: PNG（支持透明背景）
- **Brand Visibility**: `/public/features/brand-visibility.png`
  - 建议尺寸: 1920×1440px 或更高（4:3 比例）
  - 格式: PNG（支持透明背景）
- **Sentiment Analysis**: `/public/features/sentiment-analysis.png`
  - 建议尺寸: 1920×1440px 或更高（4:3 比例）
  - 格式: PNG（支持透明背景）

---

## 💻 技术实现要求

### 技术栈
- **框架**: Next.js 14 (App Router)
- **语言**: TypeScript
- **样式**: Tailwind CSS
- **UI 库**: Radix UI (Button 组件使用 @radix-ui/react-slot)
- **工具库**: 
  - `clsx` - className 合并
  - `tailwind-merge` - Tailwind 类名合并
  - `class-variance-authority` - 组件变体管理

### 组件依赖

#### Button 组件
- **位置**: `src/components/ui/button.tsx`
- **变体**:
  - `default`: 主按钮（brand-600 背景）
  - `outline`: 边框按钮
  - `ghost`: 透明背景按钮
- **尺寸**:
  - `sm`: 小号（h-9, px-3）
  - `default`: 标准（h-10, px-4）
  - `lg`: 大号（h-11, px-8）

#### Logo 组件
- **位置**: `src/components/logo.tsx`
- **Props**:
  - `size`: 高度（像素），默认 40px
  - `className`: 自定义样式类

#### LandingHeader 组件
- **位置**: `src/components/landing-header.tsx`
- **功能**: 导航栏组件，包含 Logo、导航链接、操作按钮

### 路由要求

所有链接必须指向以下路由：
- `/` - Landing page（本页面）
- `/pricing` - 定价页面
- `/docs` - 文档页面
- `/news` - Blog 页面（显示为 "Blog"）
- `/login` - 登录页面
- `/signup` - 注册页面
- `/privacy` - 隐私政策
- `/terms` - 服务条款
- `/imprint` - 法律声明

---

## 📱 响应式设计要求

### 断点
- **sm**: 640px 及以上（小屏幕）
- **md**: 768px 及以上（中等屏幕）
- **lg**: 1024px 及以上（大屏幕）
- **xl**: 1280px 及以上（超大屏幕）
- **2xl**: 1400px 及以上（最大容器宽度）

### 响应式行为

#### Header
- **移动端** (< 768px): 导航链接隐藏，可能需要汉堡菜单
- **桌面端** (≥ 768px): 显示所有导航链接

#### Hero Section
- **移动端**: 
  - 标题字号: `text-4xl`
  - 按钮垂直排列: `flex-col`
  - 按钮全宽: `w-full`
- **桌面端**:
  - 标题字号: `text-5xl lg:text-6xl`
  - 按钮水平排列: `flex-row`
  - 按钮自适应宽度: `w-auto`

#### Features Section
- **移动端**: 所有功能卡片垂直排列，文字和图片都全宽
- **桌面端**: 
  - Feature 1 & 3: 文字在左（2/5），图片在右（3/5）
  - Feature 2: 图片在左（3/5），文字在右（2/5）

#### Footer
- **移动端**: 3 列变为单列，垂直排列
- **桌面端**: 3 列网格布局

---

## 🎯 交互要求

### 按钮交互
- **Hover 状态**: 
  - 主按钮: `bg-brand-700`
  - Outline 按钮: `bg-ink-50 border-ink-300`
  - Ghost 按钮: `bg-ink-50 text-ink-900`
- **Active 状态**:
  - 主按钮: `bg-brand-800`
  - Outline 按钮: `bg-ink-100`
  - Ghost 按钮: `bg-ink-100`
- **过渡效果**: `transition-all duration-200`

### 链接交互
- **导航链接**: `hover:text-brand-600 transition-colors`
- **Footer 链接**: `hover:text-white transition-colors`

### Header 交互
- **Sticky 定位**: 滚动时固定在顶部
- **背景模糊**: `backdrop-blur` 效果
- **背景透明度**: `bg-white/95`（支持 backdrop-filter 时 `bg-white/60`）

---

## 📦 源代码文件清单

### 必须提供的文件

1. **主页面文件**
   - `src/app/page.tsx` - Landing page 主组件

2. **组件文件**
   - `src/components/landing-header.tsx` - Header 组件
   - `src/components/logo.tsx` - Logo 组件
   - `src/components/ui/button.tsx` - Button 组件

3. **工具文件**
   - `src/lib/utils.ts` - 工具函数（cn 函数）

4. **配置文件**
   - `tailwind.config.ts` - Tailwind 配置
   - `src/app/globals.css` - 全局样式

### 文件内容要求

所有文件必须：
- 使用 TypeScript
- 遵循 Next.js 14 App Router 规范
- 使用 Tailwind CSS 类名
- 保持代码格式一致
- 包含必要的注释

---

## ✅ 交付要求

### 设计稿交付
1. **桌面端设计稿** (1920×1080 或 1440×900)
2. **移动端设计稿** (375×812 iPhone 或 390×844)
3. **平板端设计稿** (768×1024 iPad) - 可选
4. **设计规范文档**（包含颜色、字体、间距等）

### 代码交付
1. **完整的源代码文件**（见上方清单）
2. **资源文件**（Logo、功能截图）
3. **README 文档**（说明如何集成到现有项目）

### 质量要求
1. **响应式**: 必须在所有断点下正常显示
2. **性能**: 图片需要优化（WebP 格式，适当压缩）
3. **可访问性**: 符合 WCAG 2.1 AA 标准
4. **浏览器兼容**: 支持 Chrome、Firefox、Safari、Edge（最新 2 个版本）

---

## 🔗 相关链接

- **产品官网**: [待填写]
- **设计系统文档**: [待填写]
- **品牌指南**: [待填写]

---

## 📝 注意事项

1. **图片占位符**: 如果功能截图不存在，需要显示友好的占位文本
2. **Logo 备用方案**: 如果 Logo 文件不存在，显示文字 "ximu"
3. **外部链接**: 社交媒体链接需要在 `target="_blank" rel="noopener noreferrer"` 下打开
4. **年份动态**: Footer 中的版权年份需要使用 JavaScript 动态获取当前年份
5. **SEO 优化**: 确保所有图片都有 `alt` 属性
6. **性能优化**: 使用 Next.js Image 组件优化图片加载

---

## 📞 联系方式

如有任何问题，请联系：
- **项目负责人**: [待填写]
- **技术负责人**: [待填写]

---

**文档版本**: 1.0  
**最后更新**: 2025-01-XX

