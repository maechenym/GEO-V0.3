# Landing Page 设计文件包

## 📦 文件说明

本文件包包含 ximu landing page 重新设计所需的所有文件。

### 📋 文档文件
- `LANDING_PAGE_DESIGN_BRIEF.md` - 完整的设计需求文档（**请先阅读此文件**）
- `LANDING_PAGE_FILE_CHECKLIST.md` - 文件清单
- `LANDING_PAGE_README.md` - 快速开始指南

### 💻 源代码文件
- `src/app/page.tsx` - Landing page 主组件
- `src/components/landing-header.tsx` - Header 组件
- `src/components/logo.tsx` - Logo 组件
- `src/components/ui/button.tsx` - Button 组件
- `src/lib/utils.ts` - 工具函数
- `tailwind.config.ts` - Tailwind 配置
- `src/app/globals.css` - 全局样式

### 🖼️ 资源文件
- `public/ximu-logo-horizontal-blue.svg` - 蓝色 Logo（Header 使用）
- `public/ximu-logo-horizontal-white.svg` - 白色 Logo（Footer 使用）
- `public/features/` - 功能截图（如果存在）

## 🚀 快速开始

1. **首先阅读**: `LANDING_PAGE_DESIGN_BRIEF.md` - 了解完整的设计需求
2. **查看清单**: `LANDING_PAGE_FILE_CHECKLIST.md` - 确认所有文件
3. **开始设计**: 根据设计需求文档进行设计

## 📝 注意事项

- 所有源代码文件使用 TypeScript 和 Next.js 14 App Router
- 样式使用 Tailwind CSS
- Logo 文件为 SVG 格式，可缩放
- 功能截图如果不存在，需要设计师创建占位图或提供设计稿

## 📞 联系方式

如有任何问题，请参考设计需求文档或联系项目负责人。

---
**打包时间**: $(date)
